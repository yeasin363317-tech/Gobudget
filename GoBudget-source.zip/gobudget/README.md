# GoBudget (Phase 2)
Offline-first Android finance app. React + TS + Vite + Tailwind + Dexie + Capacitor.

Done in phase 1: wallets, income/expense, transfers, multi-currency with saved rate snapshots (integer minor units, BigInt conversion), dashboard, search/filter, dark/light, Android back button.
Not yet: analytics, budgets, savings goals, recurring, backup/restore, AdMob, landing page, edit transaction.
Status: code was written WITHOUT running install/tsc/tests (no network in authoring env). Fix any CI errors first.

## Build APK (no PC needed)
1. Upload this folder to a new GitHub repo (branch main).
2. Actions tab -> "Build Android APK" -> Run workflow.
3. Open finished run -> Artifacts -> GoBudget-debug-apk -> download, unzip, install app-debug.apk.

## Local
npm install && npm run typecheck && npm test && npm run build
npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug
