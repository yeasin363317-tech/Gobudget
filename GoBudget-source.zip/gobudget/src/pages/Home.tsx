import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import { walletBalances } from '../services/finance';
import { fmt, today } from '../lib/money';
import { TxList } from './Transactions';

export function Home({ onAdd }: { onAdd: () => void }) {
  const base = useLiveQuery(() => db.settings.get('baseCurrency'), [])?.value ?? 'BDT';
  const data = useLiveQuery(async () => {
    const start = today().slice(0, 8) + '01';
    const [txs, bal, ws] = await Promise.all([db.transactions.toArray(), walletBalances(), db.wallets.toArray()]);
    const month = txs.filter((t) => t.date >= start && t.baseCurrency === base);
    const sum = (ty: string) => month.filter((t) => t.type === ty).reduce((s, t) => s + t.baseAmountMinor, 0);
    const total = ws.filter((w) => w.currency === base).reduce((s, w) => s + (bal[w.id] ?? 0), 0);
    const other = ws.some((w) => w.currency !== base);
    return { income: sum('income'), expense: sum('expense'), total, other, count: txs.length, recent: [...txs].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt).slice(0, 5) };
  }, [base]);
  if (!data) return null;
  return (
    <div>
      <div className="glass p-5 mb-4">
        <p className="muted text-sm">Total balance ({base} wallets)</p>
        <p className="text-3xl font-bold mt-1">{fmt(data.total, base)}</p>
        {data.other && <p className="muted text-xs mt-2">Wallets in other currencies are shown separately in Wallets (never added without conversion).</p>}
      </div>
      <div className="grid grid-cols-2 gap-3 mb-5">
        <div className="glass p-4"><p className="muted text-sm">Income (this month)</p><p className="font-semibold mt-1" style={{ color: 'var(--income)' }}>{fmt(data.income, base)}</p></div>
        <div className="glass p-4"><p className="muted text-sm">Expenses (this month)</p><p className="font-semibold mt-1" style={{ color: 'var(--expense)' }}>{fmt(data.expense, base)}</p></div>
      </div>
      <h2 className="font-semibold mb-3">Recent transactions</h2>
      {data.count === 0 ? (
        <div className="glass p-6 text-center"><p className="muted mb-4">No transactions yet. Start by adding your first one.</p><button className="btn" onClick={onAdd}>Add Transaction</button></div>
      ) : <TxList items={data.recent} />}
    </div>
  );
}
