import { useLiveQuery } from 'dexie-react-hooks';
import { motion } from 'framer-motion';
import { ArrowLeftRight, Plus } from 'lucide-react';
import { db } from '../db';
import { walletBalances } from '../services/finance';
import { getRate } from '../services/fx';
import { convertMinor, fmt, today } from '../lib/money';
import { Reveal } from '../components/Reveal';
import { TxList } from './Transactions';

export function Home({ onAdd, onRates }: { onAdd: () => void; onRates: () => void }) {
  const base = useLiveQuery(() => db.settings.get('baseCurrency'), [])?.value ?? 'BDT';
  const data = useLiveQuery(async () => {
    const start = today().slice(0, 8) + '01';
    const [txs, bal, ws] = await Promise.all([db.transactions.toArray(), walletBalances(), db.wallets.toArray()]);
    const month = txs.filter((t) => t.date >= start && t.baseCurrency === base);
    const sum = (ty: string) => month.filter((t) => t.type === ty).reduce((s, t) => s + t.baseAmountMinor, 0);
    let total = 0; const missing: string[] = [];
    for (const w of ws) {
      const r = await getRate(w.currency, base);
      const c = r ? convertMinor(bal[w.id] ?? 0, w.currency, base, r) : null;
      if (c === null) { if (!missing.includes(w.currency)) missing.push(w.currency); } else total += c;
    }
    return { income: sum('income'), expense: sum('expense'), total, missing, count: txs.length, recent: [...txs].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt).slice(0, 5) };
  }, [base]);
  if (!data) return null;
  const flow = data.income + data.expense;
  const pct = flow === 0 ? 0 : Math.round((data.income / flow) * 100);
  return (
    <div>
      <Reveal>
        <div className="hero mb-4">
          <div className="flex items-center justify-between">
            <p className="text-sm opacity-90">Total balance ({base})</p>
            <button className="rounded-full p-2 bg-white/20" onClick={onRates} aria-label="Exchange rates"><ArrowLeftRight size={18} strokeWidth={2} /></button>
          </div>
          <p className="text-4xl font-bold mt-2 tracking-tight">{fmt(data.total, base)}</p>
          {data.missing.length > 0 && <p className="text-xs mt-3 opacity-90">{data.missing.join(', ')} wallet balance not included: set a rate to {base} (tap the arrows icon).</p>}
        </div>
      </Reveal>
      <Reveal i={1} className="grid grid-cols-2 gap-3 mb-4">
        <div className="glass p-4"><p className="muted text-sm">Income (month)</p><p className="font-semibold mt-1" style={{ color: 'var(--income)' }}>{fmt(data.income, base)}</p></div>
        <div className="glass p-4"><p className="muted text-sm">Expenses (month)</p><p className="font-semibold mt-1" style={{ color: 'var(--expense)' }}>{fmt(data.expense, base)}</p></div>
      </Reveal>
      <Reveal i={2}>
        <div className="glass p-4 mb-5">
          <p className="muted text-sm mb-2">Income vs expense this month</p>
          <div className="h-3 rounded-full overflow-hidden flex" style={{ background: 'var(--expense)' }}>
            <motion.div style={{ background: 'var(--income)' }} initial={{ width: 0 }} animate={{ width: `${flow === 0 ? 50 : pct}%` }} transition={{ duration: 0.8, ease: 'easeOut' }} />
          </div>
        </div>
      </Reveal>
      <h2 className="font-semibold mb-3">Recent transactions</h2>
      {data.count === 0 ? (
        <div className="glass p-6 text-center"><p className="muted mb-4">No transactions yet. Start by adding your first one.</p><button className="btn inline-flex items-center gap-2" onClick={onAdd}><Plus size={18} /> Add Transaction</button></div>
      ) : <TxList items={data.recent} />}
    </div>
  );
}
