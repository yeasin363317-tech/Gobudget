import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Trash2, Plus, Banknote, Landmark, Smartphone, CreditCard, Wallet as WalletIcon } from 'lucide-react';
import { db } from '../db';
import { addWallet, deleteWallet, walletBalances } from '../services/finance';
import { CURRENCIES, fmt } from '../lib/money';
import { WALLET_TYPES } from '../types';
import { Sheet, Field } from '../components/Sheet';
import { Reveal } from '../components/Reveal';

const ICONS: Record<string, typeof Banknote> = { Cash: Banknote, 'Bank Account': Landmark, 'Mobile Banking': Smartphone, 'Digital Wallet': CreditCard, Other: WalletIcon };

export function Wallets() {
  const data = useLiveQuery(async () => ({ ws: await db.wallets.toArray(), bal: await walletBalances() }), []);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: '', type: 'Cash', currency: 'BDT', opening: '' });
  const [err, setErr] = useState('');
  const save = async () => { const e = await addWallet(f); if (e) setErr(e); else { setOpen(false); setF({ name: '', type: 'Cash', currency: f.currency, opening: '' }); setErr(''); } };
  const remove = async (id: string) => { if (!confirm('Delete this wallet?')) return; const e = await deleteWallet(id); if (e) alert(e); };
  return (
    <div>
      <button className="btn w-full mb-4 flex items-center justify-center gap-2" onClick={() => setOpen(true)}><Plus size={20} strokeWidth={2} /> Add Wallet</button>
      {data && data.ws.length === 0 && <p className="muted text-center mt-10">No wallets yet. Add your first wallet.</p>}
      {data?.ws.map((w, i) => {
        const Icon = ICONS[w.type] ?? WalletIcon;
        return (
          <Reveal key={w.id} i={i} className="glass p-4 mb-3 flex items-center gap-3">
            <span className="badge" style={{ color: 'var(--primary)', background: 'color-mix(in srgb, var(--primary) 16%, transparent)' }}><Icon size={20} strokeWidth={2} /></span>
            <div className="flex-1"><p className="font-medium">{w.name}</p><p className="muted text-xs">{w.type} · {w.currency}</p></div>
            <p className="font-semibold">{fmt(data.bal[w.id] ?? 0, w.currency)}</p>
            <button className="btn-ghost !px-2" aria-label="Delete wallet" onClick={() => remove(w.id)}><Trash2 size={18} strokeWidth={2} /></button>
          </Reveal>
        );
      })}
      {open && (
        <Sheet title="New wallet" onClose={() => setOpen(false)}>
          <Field label="Name"><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="Type"><select className="input" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>{WALLET_TYPES.map((t) => <option key={t}>{t}</option>)}</select></Field>
          <Field label="Currency"><select className="input" value={f.currency} onChange={(e) => setF({ ...f, currency: e.target.value })}>{Object.entries(CURRENCIES).map(([c, v]) => <option key={c} value={c}>{c} — {v.name}</option>)}</select></Field>
          <Field label="Opening balance"><input className="input" inputMode="decimal" value={f.opening} onChange={(e) => setF({ ...f, opening: e.target.value })} placeholder="0" /></Field>
          {err && <p role="alert" className="mb-3" style={{ color: 'var(--expense)' }}>{err}</p>}
          <button className="btn w-full" onClick={save}>Save wallet</button>
        </Sheet>
      )}
    </div>
  );
}
