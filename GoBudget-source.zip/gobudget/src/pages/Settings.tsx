import { useLiveQuery } from 'dexie-react-hooks';
import { ArrowLeftRight, ChevronRight } from 'lucide-react';
import { db, setSetting } from '../db';
import { CURRENCIES } from '../lib/money';
import { Field } from '../components/Sheet';
import { Reveal } from '../components/Reveal';

export function Settings({ onRates }: { onRates: () => void }) {
  const theme = useLiveQuery(() => db.settings.get('theme'), [])?.value ?? 'system';
  const base = useLiveQuery(() => db.settings.get('baseCurrency'), [])?.value ?? 'BDT';
  return (
    <div>
      <Reveal className="glass p-4 mb-4">
        <Field label="Theme"><select className="input" value={theme} onChange={(e) => setSetting('theme', e.target.value)}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></Field>
        <Field label="Base currency (for totals)"><select className="input" value={base} onChange={(e) => setSetting('baseCurrency', e.target.value)}>{Object.entries(CURRENCIES).map(([c, v]) => <option key={c} value={c}>{c} — {v.name}</option>)}</select></Field>
        <p className="muted text-xs">Old transactions keep the rate and base amount saved when they were created.</p>
      </Reveal>
      <Reveal i={1}>
        <button className="glass w-full p-4 mb-4 flex items-center gap-3 text-left" onClick={onRates}>
          <span className="badge" style={{ color: 'var(--primary)', background: 'color-mix(in srgb, var(--primary) 16%, transparent)' }}><ArrowLeftRight size={20} /></span>
          <span className="flex-1 font-medium">Exchange rates &amp; converter</span><ChevronRight size={18} className="muted" />
        </button>
      </Reveal>
      <Reveal i={2} className="glass p-4 mb-4">
        <p className="font-medium mb-1">Privacy</p>
        <p className="muted text-sm">All data stays on this device. No account, no cloud. Uninstalling the app or clearing its storage deletes your data, so backup export (coming soon) is important.</p>
      </Reveal>
      <p className="muted text-center text-sm">GoBudget v1.0.0</p>
    </div>
  );
}
