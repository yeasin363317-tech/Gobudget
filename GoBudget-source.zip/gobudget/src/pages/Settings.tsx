import { useLiveQuery } from 'dexie-react-hooks';
import { db, setSetting } from '../db';
import { CURRENCIES } from '../lib/money';
import { Field } from '../components/Sheet';

export function Settings() {
  const theme = useLiveQuery(() => db.settings.get('theme'), [])?.value ?? 'system';
  const base = useLiveQuery(() => db.settings.get('baseCurrency'), [])?.value ?? 'BDT';
  return (
    <div>
      <div className="glass p-4 mb-4">
        <Field label="Theme"><select className="input" value={theme} onChange={(e) => setSetting('theme', e.target.value)}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></Field>
        <Field label="Base currency (for totals)"><select className="input" value={base} onChange={(e) => setSetting('baseCurrency', e.target.value)}>{Object.entries(CURRENCIES).map(([c, v]) => <option key={c} value={c}>{c} — {v.name}</option>)}</select></Field>
        <p className="muted text-xs">Old transactions keep the rate and base amount saved when they were created.</p>
      </div>
      <div className="glass p-4 mb-4">
        <p className="font-medium mb-1">Privacy</p>
        <p className="muted text-sm">All data stays on this device. No account, no cloud. Uninstalling the app or clearing its storage deletes your data, so backup export (coming in the next phase) is important.</p>
      </div>
      <p className="muted text-center text-sm">GoBudget v1.0.0</p>
    </div>
  );
}
