import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Trash2, Search } from 'lucide-react';
import { db } from '../db';
import { deleteTx } from '../services/finance';
import { fmt } from '../lib/money';
import type { Tx } from '../types';

export function TxList({ items }: { items: Tx[] }) {
  const cats = useLiveQuery(() => db.categories.toArray(), []) ?? [];
  const ws = useLiveQuery(() => db.wallets.toArray(), []) ?? [];
  const name = (id: string) => cats.find((c) => c.id === id)?.name ?? '—';
  const wname = (id: string) => ws.find((w) => w.id === id)?.name ?? '—';
  const groups = items.reduce<Record<string, Tx[]>>((g, t) => { (g[t.date] ??= []).push(t); return g; }, {});
  return (
    <div>
      {Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0])).map(([date, list]) => (
        <div key={date} className="mb-4">
          <p className="muted text-sm mb-2">{date}</p>
          {list.map((t) => (
            <div key={t.id} className="glass p-3 mb-2 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{name(t.categoryId)}</p>
                <p className="muted text-xs truncate">{wname(t.walletId)}{t.note ? ` · ${t.note}` : ''}</p>
                {t.currency !== t.baseCurrency && <p className="muted text-xs">Rate {t.rate} → {fmt(t.baseAmountMinor, t.baseCurrency)}</p>}
              </div>
              <p className="font-semibold" style={{ color: t.type === 'income' ? 'var(--income)' : 'var(--expense)' }}>{t.type === 'income' ? '+' : '−'}{fmt(t.amountMinor, t.currency)}</p>
              <button className="btn-ghost !px-2" aria-label="Delete transaction" onClick={() => { if (confirm('Delete this transaction?')) deleteTx(t.id); }}><Trash2 size={18} strokeWidth={2} /></button>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export function Transactions() {
  const [q, setQ] = useState('');
  const [type, setType] = useState('all');
  const items = useLiveQuery(() => db.transactions.toArray(), []) ?? [];
  const cats = useLiveQuery(() => db.categories.toArray(), []) ?? [];
  const shown = items.filter((t) => (type === 'all' || t.type === type) && `${t.note} ${cats.find((c) => c.id === t.categoryId)?.name ?? ''}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <div className="relative mb-3"><Search size={18} className="absolute left-3 top-3.5 muted" /><input className="input !pl-10" placeholder="Search note or category" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      <div className="flex gap-2 mb-4">{['all', 'income', 'expense'].map((x) => <button key={x} className={type === x ? 'btn !min-h-[38px]' : 'btn-ghost !min-h-[38px]'} onClick={() => setType(x)}>{x[0].toUpperCase() + x.slice(1)}</button>)}</div>
      {shown.length === 0 ? <p className="muted text-center mt-10">No transactions found.</p> : <TxList items={shown} />}
    </div>
  );
}
