import { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Home as HomeIcon, ListOrdered, Wallet, Settings as SettingsIcon, Plus } from 'lucide-react';
import { App as CapApp } from '@capacitor/app';
import { db } from './db';
import { Home } from './pages/Home';
import { Transactions } from './pages/Transactions';
import { Wallets } from './pages/Wallets';
import { Settings } from './pages/Settings';
import { AddSheet } from './components/AddSheet';

const TABS = [['home', 'Home', HomeIcon], ['tx', 'Transactions', ListOrdered], ['wallets', 'Wallets', Wallet], ['settings', 'Settings', SettingsIcon]] as const;
type Tab = (typeof TABS)[number][0];

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const [adding, setAdding] = useState(false);
  const theme = useLiveQuery(() => db.settings.get('theme'), [])?.value ?? 'system';

  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => document.documentElement.classList.toggle('dark', theme === 'dark' || (theme === 'system' && mq.matches));
    apply(); mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [theme]);

  useEffect(() => {
    const h = CapApp.addListener('backButton', () => {
      if (adding) setAdding(false); else if (tab !== 'home') setTab('home'); else CapApp.exitApp();
    });
    return () => { h.then((x) => x.remove()); };
  }, [adding, tab]);

  const title = TABS.find((t) => t[0] === tab)![1];
  return (
    <div className="max-w-md mx-auto px-4 safe-top" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom,0px) + 110px)' }}>
      <h1 className="text-2xl font-bold mb-4">{tab === 'home' ? 'GoBudget' : title}</h1>
      {tab === 'home' && <Home onAdd={() => setAdding(true)} />}
      {tab === 'tx' && <Transactions />}
      {tab === 'wallets' && <Wallets />}
      {tab === 'settings' && <Settings />}

      <button className="btn fixed left-1/2 -translate-x-1/2 !rounded-full !w-14 !h-14 !p-0 flex items-center justify-center z-40" style={{ bottom: 'calc(env(safe-area-inset-bottom,0px) + 62px)' }} aria-label="Add transaction" onClick={() => setAdding(true)}><Plus size={26} strokeWidth={2.2} /></button>
      <nav className="glass fixed left-3 right-3 max-w-md mx-auto grid grid-cols-4 z-30 !rounded-3xl" style={{ bottom: 'calc(env(safe-area-inset-bottom,0px) + 10px)' }}>
        {TABS.map(([id, label, Icon]) => (
          <button key={id} onClick={() => setTab(id)} aria-label={label} className="py-3 flex flex-col items-center gap-1 text-[11px]" style={{ color: tab === id ? 'var(--primary)' : 'var(--muted)' }}>
            <Icon size={22} strokeWidth={2} />{label}
          </button>
        ))}
      </nav>
      {adding && <AddSheet onClose={() => setAdding(false)} />}
    </div>
  );
}
