/**
 * Money rules (important):
 * - Amounts are stored as INTEGER minor units (paisa/cents). JPY has 0 decimals.
 * - Never use floating point for money math. Conversion uses BigInt.
 * - Rate = how many units of TARGET currency for 1 unit of SOURCE currency.
 */
export const CURRENCIES: Record<string, { name: string; d: number }> = {
  BDT: { name: 'Bangladeshi Taka', d: 2 }, USD: { name: 'US Dollar', d: 2 },
  EUR: { name: 'Euro', d: 2 }, GBP: { name: 'British Pound', d: 2 },
  INR: { name: 'Indian Rupee', d: 2 }, SAR: { name: 'Saudi Riyal', d: 2 },
  AED: { name: 'UAE Dirham', d: 2 }, JPY: { name: 'Japanese Yen', d: 0 },
  CAD: { name: 'Canadian Dollar', d: 2 }, AUD: { name: 'Australian Dollar', d: 2 },
};
export const decimals = (c: string) => CURRENCIES[c]?.d ?? 2;

/** "12.50" -> 1250. Returns null if invalid or too many decimals. */
export function toMinor(input: string, cur: string): number | null {
  const s = input.trim().replace(/,/g, '');
  if (!/^\d+(\.\d+)?$/.test(s)) return null;
  const [i, f = ''] = s.split('.');
  const d = decimals(cur);
  if (f.length > d) return null;
  const n = Number(i + f.padEnd(d, '0'));
  return Number.isSafeInteger(n) ? n : null;
}

export function fromMinorString(minor: number, cur: string): string {
  const d = decimals(cur);
  const neg = minor < 0;
  const s = String(Math.abs(minor)).padStart(d + 1, '0');
  const out = d === 0 ? s : `${s.slice(0, -d)}.${s.slice(-d)}`;
  return neg ? `-${out}` : out;
}

/** Display only (never used for calculations). */
export function fmt(minor: number, cur: string): string {
  const d = decimals(cur);
  try {
    return new Intl.NumberFormat('en', { style: 'currency', currency: cur, minimumFractionDigits: d, maximumFractionDigits: d }).format(Number(fromMinorString(minor, cur)));
  } catch { return `${fromMinorString(minor, cur)} ${cur}`; }
}

const RATE_SCALE = 8;
export function parseRate(s: string): bigint | null {
  const t = s.trim();
  if (!/^\d+(\.\d{1,8})?$/.test(t)) return null;
  const [i, f = ''] = t.split('.');
  const v = BigInt(i + f.padEnd(RATE_SCALE, '0'));
  return v > 0n ? v : null;
}

/** Convert minor units between currencies using a decimal rate string. Rounds half up. */
export function convertMinor(minor: number, from: string, to: string, rate: string): number | null {
  const r = parseRate(rate);
  if (r === null) return null;
  const num = BigInt(minor) * r * 10n ** BigInt(decimals(to));
  const den = 10n ** BigInt(RATE_SCALE) * 10n ** BigInt(decimals(from));
  return Number((num * 2n + den) / (2n * den));
}

export const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
