import { describe, it, expect } from 'vitest';
import { toMinor, fromMinorString, convertMinor } from './money';
describe('money', () => {
  it('parses minor units', () => { expect(toMinor('12.5', 'USD')).toBe(1250); expect(toMinor('100', 'JPY')).toBe(100); expect(toMinor('1.5', 'JPY')).toBeNull(); });
  it('formats minor units', () => { expect(fromMinorString(1250, 'USD')).toBe('12.50'); expect(fromMinorString(5, 'USD')).toBe('0.05'); });
  it('converts exactly', () => { expect(convertMinor(1000, 'USD', 'BDT', '120')).toBe(120000); expect(convertMinor(1000, 'USD', 'JPY', '150.5')).toBe(1505); expect(convertMinor(10, 'USD', 'USD', '0.5')).toBe(5); });
  it('rejects bad rates', () => { expect(convertMinor(100, 'USD', 'BDT', 'abc')).toBeNull(); expect(convertMinor(100, 'USD', 'BDT', '0')).toBeNull(); });
});
