import { db } from '../db';
import { parseRate, inverseRate } from '../lib/money';

export const rateId = (from: string, to: string) => `${from}>${to}`;

/** Saved rate (manual). Uses the inverse of the opposite pair if only that one exists. */
export async function getRate(from: string, to: string): Promise<string | null> {
  if (from === to) return '1';
  const d = await db.fxRates.get(rateId(from, to));
  if (d) return d.rate;
  const i = await db.fxRates.get(rateId(to, from));
  return i ? inverseRate(i.rate) : null;
}

export async function saveRate(from: string, to: string, rate: string): Promise<string | null> {
  if (from === to) return 'Choose two different currencies';
  if (parseRate(rate) === null) return 'Enter a valid rate (up to 8 decimals)';
  await db.fxRates.put({ id: rateId(from, to), from, to, rate: rate.trim(), updatedAt: Date.now() });
  return null;
}
