import { db, getSetting } from '../db';
import { toMinor, convertMinor, parseRate } from '../lib/money';
import type { TxType, Wallet } from '../types';

/** Balance = opening + income - expense + transfers in - transfers out (computed, never stored). */
export async function walletBalances(): Promise<Record<string, number>> {
  const [ws, txs, trs] = await Promise.all([db.wallets.toArray(), db.transactions.toArray(), db.transfers.toArray()]);
  const m: Record<string, number> = {};
  ws.forEach((w) => (m[w.id] = w.openingMinor));
  txs.forEach((t) => { if (t.walletId in m) m[t.walletId] += t.type === 'income' ? t.amountMinor : -t.amountMinor; });
  trs.forEach((t) => { if (t.fromWalletId in m) m[t.fromWalletId] -= t.fromMinor; if (t.toWalletId in m) m[t.toWalletId] += t.toMinor; });
  return m;
}

export async function addWallet(i: { name: string; type: string; currency: string; opening: string }): Promise<string | null> {
  if (!i.name.trim()) return 'Wallet name is required';
  const opening = toMinor(i.opening || '0', i.currency);
  if (opening === null) return 'Opening balance is invalid';
  const w: Wallet = { id: crypto.randomUUID(), name: i.name.trim(), type: i.type, currency: i.currency, openingMinor: opening, createdAt: Date.now() };
  await db.wallets.add(w);
  return null;
}

export async function deleteWallet(id: string): Promise<string | null> {
  const [a, b, c] = await Promise.all([
    db.transactions.where('walletId').equals(id).count(),
    db.transfers.where('fromWalletId').equals(id).count(),
    db.transfers.where('toWalletId').equals(id).count(),
  ]);
  if (a + b + c > 0) return 'This wallet has transaction history. Delete those transactions first.';
  await db.wallets.delete(id);
  return null;
}

export async function addTx(i: { type: TxType; amount: string; walletId: string; categoryId: string; date: string; note: string; rate: string }): Promise<string | null> {
  const w = await db.wallets.get(i.walletId);
  if (!w) return 'Select a wallet';
  if (!i.categoryId) return 'Select a category';
  if (!i.date) return 'Select a date';
  const amount = toMinor(i.amount, w.currency);
  if (!amount) return 'Enter a valid amount (check the decimal places for this currency)';
  const base = await getSetting('baseCurrency', 'BDT');
  const rate = w.currency === base ? '1' : i.rate.trim();
  if (parseRate(rate) === null) return `Enter exchange rate (1 ${w.currency} = ? ${base})`;
  const baseAmount = convertMinor(amount, w.currency, base, rate);
  if (baseAmount === null) return 'Conversion failed';
  const now = Date.now();
  await db.transactions.add({ id: crypto.randomUUID(), type: i.type, amountMinor: amount, currency: w.currency, categoryId: i.categoryId, walletId: w.id, date: i.date, note: i.note.trim(), createdAt: now, updatedAt: now, rate, baseCurrency: base, baseAmountMinor: baseAmount });
  return null;
}

export const deleteTx = (id: string) => db.transactions.delete(id);

export async function addTransfer(i: { from: string; to: string; sent: string; received: string; date: string; note: string }): Promise<string | null> {
  if (!i.from || !i.to) return 'Select both wallets';
  if (i.from === i.to) return 'Choose two different wallets';
  const [a, b] = await Promise.all([db.wallets.get(i.from), db.wallets.get(i.to)]);
  if (!a || !b) return 'Wallet not found';
  const sent = toMinor(i.sent, a.currency);
  if (!sent) return 'Enter a valid amount to send';
  const recv = a.currency === b.currency ? sent : toMinor(i.received, b.currency);
  if (!recv) return `Enter the amount received in ${b.currency}`;
  await db.transfers.add({ id: crypto.randomUUID(), fromWalletId: a.id, toWalletId: b.id, fromMinor: sent, toMinor: recv, date: i.date, note: i.note.trim(), createdAt: Date.now() });
  return null;
}
