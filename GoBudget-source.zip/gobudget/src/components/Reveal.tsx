import { motion } from 'framer-motion';
import type { ReactNode } from 'react';
export const Reveal = ({ i = 0, children, className }: { i?: number; children: ReactNode; className?: string }) => (
  <motion.div className={className} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.045, duration: 0.3, ease: 'easeOut' }}>
    {children}
  </motion.div>
);
