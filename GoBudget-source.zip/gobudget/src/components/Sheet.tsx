import { X } from 'lucide-react';
import type { ReactNode } from 'react';
export function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/50" onClick={onClose}>
      <div className="sheet glass w-full max-w-md mx-auto rounded-b-none p-5 max-h-[90vh] overflow-y-auto" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom,0px) + 20px)' }} onClick={(e) => e.stopPropagation()} role="dialog" aria-label={title}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button className="btn-ghost !px-3" onClick={onClose} aria-label="Close"><X size={20} strokeWidth={2} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
export const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="block mb-3"><span className="muted text-sm mb-1 block">{label}</span>{children}</label>
);
