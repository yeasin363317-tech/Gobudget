import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import { getRate, saveRate } from '../services/fx';
import { CURRENCIES, toMinor, convertMinor, fmt } from '../lib/money';
import { Sheet, Field } from './Sheet';

const Cur = ({ value, onChange }: { value: string; onChange: (v: string) => void }) => (
  <select className="input" value={value} onChange={(e) => onChange(e.target.value)}>{Object.keys(CURRENCIES).map((c) => <option key={c}>{c}</option>)}</select>
);

export function RatesSheet({ onClose }: { onClose: () => void }) {
  const [from, setFrom] = useState('USD');
  const [to, setTo] = useState('BDT');
  const [rate, setRate] = useState('');
  const [amt, setAmt] = useState('1');
  const [msg, setMsg] = useState('');
  const all = useLiveQuery(() => db.fxRates.toArray(), []) ?? [];
  const current = useLiveQuery(() => getRate(from, to), [from, to]);
  const result = useLiveQuery(async () => {
    const m = toMinor(amt, from);
    if (!m) return null;
    const r = await getRate(from, to);
    if (!r) return 'No rate saved';
    const o = convertMinor(m, from, to, r);
    return o === null ? null : fmt(o, to);
  }, [amt, from, to]);

  const save = async () => { const e = await saveRate(from, to, rate); setMsg(e ?? 'Rate saved'); if (!e) setRate(''); };
  return (
    <Sheet title="Exchange rates" onClose={onClose}>
      <div className="grid grid-cols-2 gap-3">
        <Field label="From"><Cur value={from} onChange={setFrom} /></Field>
        <Field label="To"><Cur value={to} onChange={setTo} /></Field>
      </div>
      <div className="glass p-4 mb-4">
        <p className="muted text-sm">Saved rate</p>
        <p className="font-semibold">{current ? `1 ${from} = ${current} ${to}` : 'Not set yet'}</p>
      </div>
      <Field label={`Set rate: 1 ${from} = ? ${to}`}><input className="input" inputMode="decimal" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="e.g. 122.50" /></Field>
      <button className="btn w-full mb-2" onClick={save}>Save rate</button>
      {msg && <p className="muted text-sm mb-3" role="status">{msg}</p>}
      <p className="font-semibold mt-4 mb-2">Converter</p>
      <Field label={`Amount (${from})`}><input className="input" inputMode="decimal" value={amt} onChange={(e) => setAmt(e.target.value)} /></Field>
      <p className="text-2xl font-bold mb-4">{result ?? '—'}</p>
      {all.length > 0 && <>
        <p className="font-semibold mb-2">All saved rates</p>
        {all.map((r) => <div key={r.id} className="glass p-3 mb-2 flex justify-between text-sm"><span>1 {r.from} = {r.rate} {r.to}</span><span className="muted">{new Date(r.updatedAt).toLocaleDateString()}</span></div>)}
      </>}
      <p className="muted text-xs mt-3">Rates are entered by you and saved offline. Old transactions keep the rate they were created with.</p>
    </Sheet>
  );
}
