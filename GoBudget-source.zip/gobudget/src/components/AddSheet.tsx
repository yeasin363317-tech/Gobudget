import { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight } from 'lucide-react';
import { db } from '../db';
import { addTx, addTransfer } from '../services/finance';
import { getRate } from '../services/fx';
import { today } from '../lib/money';
import { Sheet, Field } from './Sheet';
import type { TxType } from '../types';

type Mode = 'menu' | TxType | 'transfer';
type Ev = { target: { value: string } };

export function AddSheet({ onClose }: { onClose: () => void }) {
  const [mode, setMode] = useState<Mode>('menu');
  const wallets = useLiveQuery(() => db.wallets.toArray(), []) ?? [];
  const cats = useLiveQuery(() => db.categories.toArray(), []) ?? [];
  const [f, setF] = useState({ amount: '', walletId: '', categoryId: '', date: today(), note: '', rate: '', to: '', received: '' });
  const [err, setErr] = useState('');
  const set = (k: keyof typeof f) => (e: Ev) => setF({ ...f, [k]: e.target.value });
  const wallet = wallets.find((w) => w.id === f.walletId);
  const toWallet = wallets.find((w) => w.id === f.to);

  if (mode === 'menu') {
    const items: [Mode, string, typeof ArrowDownLeft, string][] = [['income', 'Add Income', ArrowDownLeft, 'var(--income)'], ['expense', 'Add Expense', ArrowUpRight, 'var(--expense)'], ['transfer', 'Transfer Money', ArrowLeftRight, 'var(--primary)']];
    return (
      <Sheet title="New" onClose={onClose}>
        {items.map(([m, label, Icon, c]) => (
          <button key={m} className="glass w-full flex items-center gap-3 p-4 mb-3 text-left" onClick={() => setMode(m)}>
            <span className="badge" style={{ color: c, background: `color-mix(in srgb, ${c} 16%, transparent)` }}><Icon size={22} strokeWidth={2} /></span>
            <span className="font-medium">{label}</span>
          </button>
        ))}
      </Sheet>
    );
  }

  if (wallets.length === 0) return (
    <Sheet title="Create a wallet first" onClose={onClose}><p className="muted">Go to the Wallets tab and add a wallet (Cash, Bank, etc.) before adding transactions.</p></Sheet>
  );

  const save = async () => {
    const e = mode === 'transfer'
      ? await addTransfer({ from: f.walletId, to: f.to, sent: f.amount, received: f.received, date: f.date, note: f.note })
      : await addTx({ type: mode, amount: f.amount, walletId: f.walletId, categoryId: f.categoryId, date: f.date, note: f.note, rate: f.rate });
    if (e) setErr(e); else onClose();
  };

  return (
    <Sheet title={mode === 'income' ? 'Add Income' : mode === 'expense' ? 'Add Expense' : 'Transfer Money'} onClose={onClose}>
      <Field label={mode === 'transfer' ? 'From wallet' : 'Wallet'}>
        <select className="input" value={f.walletId} onChange={set('walletId')}><option value="">Select…</option>{wallets.map((w) => <option key={w.id} value={w.id}>{w.name} ({w.currency})</option>)}</select>
      </Field>
      {mode === 'transfer' && (
        <Field label="To wallet">
          <select className="input" value={f.to} onChange={set('to')}><option value="">Select…</option>{wallets.filter((w) => w.id !== f.walletId).map((w) => <option key={w.id} value={w.id}>{w.name} ({w.currency})</option>)}</select>
        </Field>
      )}
      <Field label={`Amount${wallet ? ` (${wallet.currency})` : ''}`}><input className="input" inputMode="decimal" value={f.amount} onChange={set('amount')} placeholder="0.00" /></Field>
      {mode === 'transfer' && wallet && toWallet && wallet.currency !== toWallet.currency && (
        <Field label={`Amount received (${toWallet.currency})`}><input className="input" inputMode="decimal" value={f.received} onChange={set('received')} /></Field>
      )}
      {mode !== 'transfer' && (
        <Field label="Category">
          <select className="input" value={f.categoryId} onChange={set('categoryId')}><option value="">Select…</option>{cats.filter((c) => c.type === mode).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        </Field>
      )}
      {mode !== 'transfer' && wallet && <RateField walletCur={wallet.currency} value={f.rate} onChange={set('rate')} onFill={(r) => setF((p) => ({ ...p, rate: r }))} />}
      <Field label="Date"><input type="date" className="input" value={f.date} onChange={set('date')} /></Field>
      <Field label="Note (optional)"><input className="input" value={f.note} onChange={set('note')} /></Field>
      {err && <p role="alert" className="mb-3" style={{ color: 'var(--expense)' }}>{err}</p>}
      <button className="btn w-full" onClick={save}>Save</button>
    </Sheet>
  );
}

function RateField({ walletCur, value, onChange, onFill }: { walletCur: string; value: string; onChange: (e: Ev) => void; onFill: (r: string) => void }) {
  const base = useLiveQuery(() => db.settings.get('baseCurrency'), [])?.value ?? 'BDT';
  useEffect(() => { if (base !== walletCur) getRate(walletCur, base).then((r) => onFill(r ?? '')); }, [walletCur, base]);
  if (base === walletCur) return null;
  return <Field label={`Exchange rate: 1 ${walletCur} = ? ${base} (filled from your saved rate, you can change it)`}><input className="input" inputMode="decimal" value={value} onChange={onChange} /></Field>;
}
