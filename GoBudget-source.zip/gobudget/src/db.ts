import Dexie, { type Table } from 'dexie';
import type { Tx, Wallet, Category, Transfer, Setting, FxRate } from './types';

export class GoBudgetDB extends Dexie {
  transactions!: Table<Tx, string>;
  categories!: Table<Category, string>;
  wallets!: Table<Wallet, string>;
  budgets!: Table<{ id: string }, string>;
  savingsGoals!: Table<{ id: string }, string>;
  savingsContributions!: Table<{ id: string; goalId: string }, string>;
  transfers!: Table<Transfer, string>;
  fxRates!: Table<FxRate, string>;
  recurringTransactions!: Table<{ id: string }, string>;
  settings!: Table<Setting, string>;
  appMeta!: Table<{ key: string; value: string }, string>;

  constructor() {
    super('GoBudgetDB');
    this.version(1).stores({
      transactions: 'id,type,walletId,categoryId,date,createdAt',
      categories: 'id,type',
      wallets: 'id,name',
      budgets: 'id',
      savingsGoals: 'id',
      savingsContributions: 'id,goalId',
      transfers: 'id,fromWalletId,toWalletId,date',
      fxRates: 'id,from,to',
      recurringTransactions: 'id',
      settings: 'key',
      appMeta: 'key',
    });
    this.on('populate', (tx) => {
      const inc = ['Salary', 'Business', 'Gift', 'Other income'];
      const exp = ['Food', 'Transport', 'Bills', 'Shopping', 'Health', 'Education', 'Rent', 'Other expense'];
      tx.table('categories').bulkAdd([
        ...inc.map((name) => ({ id: crypto.randomUUID(), name, type: 'income' })),
        ...exp.map((name) => ({ id: crypto.randomUUID(), name, type: 'expense' })),
      ]);
      tx.table('settings').bulkAdd([{ key: 'theme', value: 'system' }, { key: 'baseCurrency', value: 'BDT' }]);
      tx.table('appMeta').bulkAdd([{ key: 'schemaVersion', value: '1' }]);
    });
  }
}
export const db = new GoBudgetDB();

export async function getSetting(key: string, fallback: string) {
  return (await db.settings.get(key))?.value ?? fallback;
}
export const setSetting = (key: string, value: string) => db.settings.put({ key, value });
