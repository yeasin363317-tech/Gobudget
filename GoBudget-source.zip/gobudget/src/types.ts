export type TxType = 'income' | 'expense';
export interface Tx { id: string; type: TxType; amountMinor: number; currency: string; categoryId: string; walletId: string; date: string; note: string; createdAt: number; updatedAt: number; rate: string; baseCurrency: string; baseAmountMinor: number }
export interface Wallet { id: string; name: string; type: string; currency: string; openingMinor: number; createdAt: number }
export interface Category { id: string; name: string; type: TxType }
export interface Transfer { id: string; fromWalletId: string; toWalletId: string; fromMinor: number; toMinor: number; date: string; note: string; createdAt: number }
export interface Setting { key: string; value: string }
export const WALLET_TYPES = ['Cash', 'Bank Account', 'Mobile Banking', 'Digital Wallet', 'Other'];
export interface FxRate { id: string; from: string; to: string; rate: string; updatedAt: number }
