import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.gobudget.app',
  appName: 'GoBudget',
  webDir: 'dist',
};
export default config;
